`figCaption` <- function(label, where = c("bottomright", "bottom",
                                "bottomleft","left","topleft","top",
                                "topright","right","center"),
                         inset = 0.05, cex = 1, ...) {
    inset <- rep(inset, 2)
    usr <- par("usr")
    insetx <- inset[1L] * (usr[2L] - usr[1L])
    insety <- inset[2L] * (usr[4L] - usr[3L])
    cin <- par("cin")
    Cex <- cex * par("cex")
    text.width <- max(abs(strwidth(label, units = "user", cex = cex)))
    xc <- Cex * xinch(cin[1L], warn.log = FALSE)
    yc <- Cex * yinch(cin[2L], warn.log = FALSE)
    xchar <- xc
    xextra <- 0
    yextra <- 0
    ymax <- yc * max(1, strheight(label, units = "user", cex = cex)/yc)
    ychar <- yextra + ymax
    h <- ychar + yc
    w0 <- text.width + (1 + 1) * xchar
    w <- w0 + 0.5 * xchar
    left <- switch(where,
                   bottomright = ,
                   topright = ,
                   right = usr[2L] - w - insetx,
                   bottomleft = ,
                   left = ,
                   topleft = usr[1L] + insetx,
                   bottom = ,
                   top = , center = (usr[1L] + usr[2L] - w)/2)
    top <- switch(where,
                  bottomright = ,
                  bottom = ,
                  bottomleft = usr[3L] + h + insety,
                  topleft = ,
                  top = ,
                  topright = usr[4L] - insety,
                  left = ,
                  right = ,
                  center = (usr[3L] + usr[4L] + h)/2)
    text(left, top, label, cex = cex, ...)
}

##
`coefPlot` <- function(mod, xvar = c("norm", "lambda", "dev"),
                       label = FALSE, varNames, norm,
                       ylab = "Coefficients",
                       hoff = 1, air = 1.2,
                       allDF = FALSE, ...) {
    beta <- mod$beta
    lambda <- mod$lambda
    dev <- mod$dev.ratio
    which <- nonzeroCoef(beta)
    beta <- as.matrix(beta[which, ])
    xvar <- match.arg(xvar)
    switch(xvar, norm = {
        index <- if (missing(norm)) apply(abs(beta), 2, sum) else norm
        iname <- "L1 Norm"
    }, lambda <- {
        index <- log(lambda)
        iname <- "Log Lambda"
    }, dev = {
        index <- dev
        iname <- "Fraction Deviance Explained"
    })
    dotlist <- list(...)
    type <- dotlist$type
    if (is.null(type))
        matplot(index, t(beta), xlab = iname, ylab = ylab,
                type = "l", ...)
    else matplot(index, t(beta), xlab = xlab, ylab = ylab,
                 ...)
    df <- mod$df
    if(allDF) {
        prettyVals <- approx(x = df, y = index,
                             xout = seq_len(mod$dim[1]), rule = 2)
        atdf <- prettyVals$y
        prettydf <- prettyVals$x
    } else {
        atdf <- pretty(index)
        prettydf <- trunc(approx(x = index, y = df, xout = atdf, rule = 2)$y)
    }
    axis(3, at = atdf, label = prettydf)
    mtext("DF", side = 3, line = 2.5, cex = par("cex"))
    if (label) {
        stopifnot(require(vegan))
        if(missing(varNames))
            varNames <- mod$beta@Dimnames[[1]]
        varNames <- varNames[which]
        linestack(beta[, ncol(beta)], varNames, add = TRUE,
                  at = par("usr")[2], hoff = hoff, air = air)
        rug(beta[, ncol(beta)], side = 4, ticksize = 0.02, lwd = 1)
    }
}

`cvPlot` <- function (cvobj, sign.lambda = 1, ...) {
    xlab <- "log(Lambda)"
    if (sign.lambda < 0)
        xlab <- paste("-", xlab, sep = "")
    plot.args <- list(x = sign.lambda * log(cvobj$lambda), y = cvobj$cvm,
                      ylim = range(cvobj$cvup, cvobj$cvlo), xlab = xlab,
                      ylab = cvobj$name, type = "n")
    new.args <- list(...)
    if (length(new.args))
        plot.args[names(new.args)] <- new.args
    do.call("plot", plot.args)
    glmnet:::error.bars(sign.lambda * log(cvobj$lambda), cvobj$cvup,
                        cvobj$cvlo, width = 0.01, col = "darkgrey")
    abline(v = sign.lambda * log(cvobj$lambda.min), lty = 2)
    abline(v = sign.lambda * log(cvobj$lambda.1se), lty = 2)
    points(sign.lambda * log(cvobj$lambda), cvobj$cvm, pch = 20,
        col = "black")
    axis(side = 3, at = sign.lambda * log(cvobj$lambda),
         labels = paste(cvobj$nz), tick = FALSE, line = 0)
    invisible()
}
