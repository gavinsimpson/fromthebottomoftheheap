jackLm <- function(x, y)
{
    dif <- vector()
    fit <- vector()
    n <- length(x)
    Y <- y
    modfit <- fitted(lm(y ~ x))
    for(i in 1:n)
    {
        ydat <- y[-i]
        xdat <- x[-i]
        mod <- lm(ydat ~ xdat)
        pred <- predict(mod, newdata = data.frame(xdat = x[i]))
        fit[i] <- pred
        dif[i] <- co2$CO2[i] - pred
    }
    namx <- deparse(substitute(x))
    namy <- deparse(substitute(y))
    ans <- list(fit = fit, dif = dif, Y = Y, nobs = n, namx = namx, namy = namy, modfit = as.vector(modfit))
    class(ans) <- "jackLm"
    return(ans)
}
summary.jackLm <- function (x, digits = getOption("digits"))
{
    if (!class(x) == "jackLm") stop("x must be of class jackLm")
    resSS <- sum(x$dif^2)
    msep <- resSS / x$nobs
    rmsep <- sqrt(msep)
    totSS <- sum((x$Y - mean(x$Y))^2)
    bias <- mean(x$dif)
    rsq <- 1 - (resSS / totSS)
    adif <- x$Y - x$modfit
    aresSS <- sum(adif^2)
    amse <- aresSS / x$nobs
    armse <- sqrt(amse)
    abias <- mean(adif)
    arsq <- 1 - (aresSS / totSS)
    prediction <- data.frame(MSEP = msep, RMSEP = rmsep, Rsqr = rsq, Bias = bias)
    apparent <- data.frame(MSE = amse, RMSE = armse, Rsqr = arsq, Bias = abias)
    rownames(prediction) <- rownames(apparent) <- x$namy
    cat("\nJackknife estimated prediction error\n\n")
    cat("Apparent errors\n\n")
    print.data.frame(apparent, digits = digits, print.gap = 3)
    cat("\nPrediction errors\n\n")
    print.data.frame(prediction, digits = digits, print.gap = 3)
    cat("\n")
}
